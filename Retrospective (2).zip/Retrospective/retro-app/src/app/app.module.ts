import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { Ng5SliderModule } from 'ng5-slider';
import { AutocompleteModule } from 'ng2-input-autocomplete';
import { NgxSpinnerModule } from "ngx-spinner";
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { AppHomeComponent } from './home/app-home.component';
import { AppTempComponent } from './temp/app-temp.component';
import { AppWelcomeComponent } from './welcome/app-welcome.component';
import { AppMainComponent } from './main/app-main.component';
import { ColorPickerModule } from 'ngx-color-picker';
import { RetroInfoService } from './retrospective-tool/providers/services/retro-details.service';
import { RetroSummaryComponent } from './retrospective-tool/retro-meeting-list/retro-meeting-list.component';
import { ConstantService } from './retrospective-tool/providers/services/constant.service';
import { SearchFilterPipe } from './retrospective-tool/retrospective-live/search-filter.pipe';
import { RetrospectiveMeetingDetailsComponent } from './retrospective-tool/retrospective-live/retrospective-meeting-details.component';
import { HttpAgilePointService } from './retrospective-tool/providers/services/agile-points.service';
import { DraganddropComponent } from './retrospective-tool/draganddrop/draganddrop.component';
import { OverlayModule } from '@angular/cdk/overlay';
import { DragDropModule } from '@angular/cdk/drag-drop'
import { HttpClientService } from './retrospective-tool/providers/common/http-client.service';
import { NgImageSliderModule } from 'ng-image-slider';
import { DatePipe } from '@angular/common';
import { ContenteditableDirective } from './retrospective-tool/shared/content-editable-form.directive';
import { MatIconModule, MatSelectModule, MatAutocompleteModule, MatMenuModule } from '@angular/material';
import { MainPageComponent } from './retrospective-tool/main-page/main-page.component';
import { PrintPageComponent } from './retrospective-tool/print-page/print-page.component';
import { EditableSectionComponent } from './retrospective-tool/editable-section/editable-section.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AppHomeComponent,
    AppTempComponent,
    AppWelcomeComponent,
    AppMainComponent,
    RetroSummaryComponent,
    RetrospectiveMeetingDetailsComponent,
    DraganddropComponent,
    PrintPageComponent,
    MainPageComponent,
    EditableSectionComponent,
    ContenteditableDirective,
    SearchFilterPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatIconModule, MatSelectModule, MatMenuModule,
    ToasterModule,
    NgxSpinnerModule,
    Ng5SliderModule,
    DragDropModule,
    OverlayModule,
    ColorPickerModule,
    HttpClientModule,
    NgImageSliderModule,
    AutocompleteLibModule,
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    AppRoutingModule
  ],
  providers: [
    DatePipe,
    ConstantService,
    HttpClientService,
    ToasterService,
    RetroInfoService,
    HttpAgilePointService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
