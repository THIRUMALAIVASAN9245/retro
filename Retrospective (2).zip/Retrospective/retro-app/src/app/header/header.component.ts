import { Component, OnInit } from "@angular/core";
import { DomSanitizer } from '@angular/platform-browser';
import { ConstantService } from "../retrospective-tool/providers/services/constant.service";

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit {
    logoIconData;

    constructor(private constantService: ConstantService,
        private sanitizer: DomSanitizer) { }

    ngOnInit() {
        this.logoIconData = this.constantService.getLogoIconData()
    }

    getLogoIconData() {
        return this.sanitizer.bypassSecurityTrustResourceUrl(this.logoIconData);
    }
}