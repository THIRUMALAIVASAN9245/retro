import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppHomeComponent } from './home/app-home.component';
import { AppTempComponent } from './temp/app-temp.component';
import { AppWelcomeComponent } from './welcome/app-welcome.component';
import { AppMainComponent } from './main/app-main.component';
import { RetroSummaryComponent } from './retrospective-tool/retro-meeting-list/retro-meeting-list.component';
import { RetrospectiveMeetingDetailsComponent } from './retrospective-tool/retrospective-live/retrospective-meeting-details.component';
import { DraganddropComponent } from './retrospective-tool/draganddrop/draganddrop.component';
import { MainPageComponent } from './retrospective-tool/main-page/main-page.component';
import { PrintPageComponent } from './retrospective-tool/print-page/print-page.component';

const routes: Routes = [
  { path: '', redirectTo: '/retrospective-meeting-details', pathMatch: 'full', },
  { path: 'other', component: AppTempComponent },
  { path: 'home', component: AppHomeComponent },
  { path: 'welcome', component: AppWelcomeComponent },
  { path: 'main', component: AppMainComponent },
  { path: 'video', component: MainPageComponent },
  { path: 'video1', component: PrintPageComponent },
  { path: 'test', component: DraganddropComponent },
  { path: 'retrospective-meeting-details', component: RetroSummaryComponent },
  { path: 'retrospective', component: RetrospectiveMeetingDetailsComponent },
  { path: 'retrospective-meeting/:retroInfoId', component: RetrospectiveMeetingDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
