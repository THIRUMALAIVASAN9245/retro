import { Component, OnInit, NgZone } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

import { AgilePointDetails } from '../models/agile-point-details';
import { RetroInfoDetails } from '../models/retro-info-details';
import { ImageCategory } from '../models/image-category';
import { ToasterService } from 'angular2-toaster';
import { HttpAgilePointService } from '../providers/services/agile-points.service';
import { RetroInfoService } from '../providers/services/retro-details.service';
import { forkJoin } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@aspnet/signalr';

/**
 * @component
 * @description
 * This component add new weekly status report details for particular week
*/
@Component({
	selector: 'app-draganddrop',
	templateUrl: './draganddrop.component.html',
	styleUrls: ['./draganddrop.component.scss']
})
export class DraganddropComponent implements OnInit {
	text = 'Angular 5\nfoo';
	enabled = true;

	/**
	* @type {boolean}
	*/
	public loadingAdd;

	/**
	 * @type {AgilePointDetails}
	*/
	public agilePointDetails: AgilePointDetails[];

	/**
	 * @type {ImageCategory}
	*/
	public imageCategory: ImageCategory[];

	/**
	 * @type {RetroInfoDetails}
	*/
	public retroInfoDetails: RetroInfoDetails;

	/**
	 * @type {RetroInfo}
	*/
	public retroInfo: any;
	position = "";
	state = "";
	public RetroInfoId;
	public droppedItemsList: RetroInfoDetails[] = [];
	public addShow = false;
	public Description: string = '';
	public filterValue: string = '';
	public imageCategoryDefault = '0';
	public imageCategoryModel: ImageCategory;
	signalIRConnection = false;
	ItemsListLength: number;
	todoList: any[] = [new AgilePointDetails(21, "New Test xcvxcvxc xcvxcv xcvxcv xcvxvxcvxcv xcvxcvxcv xcvxcvcvxcv xcvxcv", "Test"),
	new AgilePointDetails(22, "New Test 2 xcvxcv xcvxcvxcvxcv xcvxcvxcvxcv xcvxcvxcvxcv xcvxcvcxv xcvxcvxcvxcv xcvxcvxcvxcvxcv", "Test"),
	new AgilePointDetails(23, "Take a shower  Take a showerTake ashower Take ashowerTake a showerTake a shower Take a shower  Take a showerTake a sh", "Test"),
	new AgilePointDetails(24, "Take a shower  Take a showerTake ashower Take a showerTake fddfgfdgfdgfdg dfgfd", "Test"),
	new AgilePointDetails(25, "New Test 5 zxczxc zxczxczxc zxczxczx zxczxc  zxczxczxczxczx czxczxc zxczxczxczxc zxczxczxc", "Test"),
	new AgilePointDetails(26, "New Test 6", "Test"),
	new AgilePointDetails(27, "New Test 7", "Test"),
	new AgilePointDetails(28, "New Test 8", "Test"),
	new AgilePointDetails(29, "New Test 9", "Test"),
	new AgilePointDetails(10, "New Test 22", "Test"),
	new AgilePointDetails(11, "New Test 33", "Test"),
	new AgilePointDetails(12, "New Test 44", "Test"),
	new AgilePointDetails(13, "New Test 45", "Test"),
	new AgilePointDetails(14, "New Test 6", "Test"),
	new AgilePointDetails(15, "New Test 76", "Test")];

	doneList: any[] = [
		{
			RetroInfoId: 1,
			RetroInfoDetailId: 1,
			RetroInfoDetailAgilePointId: 1,
			RetroInfoDetailText: "Takexcvxcvxcvxcvxcvxcvxcvxcv a showerxcvxcvxcvxcv  Take a showerTakexcvxcvxcvxcvxcvxcvxcvxcv a shower",
			RetroInfoDetailTop: 150,
			RetroInfoDetailLeft: 379,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailImageCategoryName: "red tswet",
			RetroInfoDetailColor: "red"
		},
		{
			RetroInfoId: 1,
			RetroInfoDetailId: 1,
			RetroInfoDetailAgilePointId: 2,
			RetroInfoDetailText: " Takexcvxcvxcvxcvxcvxcvxcvxcv a showerxcvxcvxcvxcv  Take a showerTakexcvxcvxcvxcv ashower Take ashowerTake a showerTake a shower Take a shower  Take a showerTake a shower",
			RetroInfoDetailTop: 180,
			RetroInfoDetailLeft: 479,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailImageCategoryName: "red tswet",
			RetroInfoDetailColor: "red"
		},
		{
			RetroInfoId: 1,
			RetroInfoDetailId: 1,
			RetroInfoDetailAgilePointId: 3,
			RetroInfoDetailText: "Takexcvxcvxcvxcvxcvxcvxcvxcv a shower  Take a showerTake a shower Take a shower  Take a showerTake a shower",
			RetroInfoDetailTop: 150,
			RetroInfoDetailLeft: 270,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailImageCategoryName: "red tswet",
			RetroInfoDetailColor: "red"
		},
		{
			RetroInfoId: 1,
			RetroInfoDetailId: 1,
			RetroInfoDetailAgilePointId: 4,
			RetroInfoDetailText: "Takexcvxcvxcvxcvxcvxcvxcvxcv a shower  Take a showerTake a shower",
			RetroInfoDetailTop: 26,
			RetroInfoDetailLeft: 327,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailImageCategoryName: "red tswet",
			RetroInfoDetailColor: "red"
		},
		{
			RetroInfoId: 1,
			RetroInfoDetailId: 1,
			RetroInfoDetailAgilePointId: 5,
			RetroInfoDetailText: "Walkxcvxcvxcvxcvxcvxcvxcvxcv Take a shower  Take a shower",
			RetroInfoDetailTop: 130,
			RetroInfoDetailLeft: 120,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailImageCategoryName: "red tswet",
			RetroInfoDetailColor: "red"
		}
	];

	/**
	 * Constructor for RetrospectiveMeetingDetailsComponent class
	 * @param route
	 * @param router
	 * @param HttpAgilePointService
	*/
	constructor(private route: ActivatedRoute,
		private httpClientService: HttpClient,
		private router: Router,
		private zone: NgZone,
		private spinner: NgxSpinnerService,
		private toasterService: ToasterService,
		private httpAgilePointService: HttpAgilePointService,
		private httpRetroInfoDetailService: RetroInfoService) {
		this.loadingAdd = true;
		// this.router.events.subscribe((evt) => {
		// 	if (!(evt instanceof NavigationEnd)) {
		// 		return;
		// 	}
		// 	window.scrollTo(0, 100)
		// });
	}

	/**
	 * @override OnInit
	*/
	ngOnInit() {
		this.RetroInfoId = 1;
		// this.GetRetroInfoDetails();
		// this.retroInfo = new RetroInfo(1, true, "Test", "Test", "Test", "Test", "02-02-2021", "");
		this.droppedItemsList = [new RetroInfoDetails(1, 1, 1, "New Test", "25", "25", 1, "Red", "Red", "Red")];
		this.agilePointDetails = [new AgilePointDetails(21, "New Test", "Test"),
		new AgilePointDetails(22, "New Test 2", "Test"),
		new AgilePointDetails(23, "New Test 3", "Test"),
		new AgilePointDetails(24, "New Test 4", "Test"),
		new AgilePointDetails(25, "New Test 5", "Test"),
		new AgilePointDetails(26, "New Test 6", "Test"),
		new AgilePointDetails(27, "New Test 7", "Test"),
		new AgilePointDetails(28, "New Test 8", "Test"),
		new AgilePointDetails(29, "New Test 9", "Test"),
		new AgilePointDetails(10, "New Test 22", "Test"),
		new AgilePointDetails(11, "New Test 33", "Test"),
		new AgilePointDetails(12, "New Test 44", "Test"),
		new AgilePointDetails(13, "New Test 45", "Test"),
		new AgilePointDetails(14, "New Test 6", "Test"),
		new AgilePointDetails(15, "New Test 76", "Test")];
		this.imageCategory = [new ImageCategory("1", "New Test", "Test", "Red", "Red")];
		this.ItemsListLength = this.droppedItemsList.length;
		this.imageCategoryDefault = "0";
		// const connection = new signalR.HubConnectionBuilder()
		//   .configureLogging(signalR.LogLevel.Information)
		//   .withUrl("https://signalrservicehub.azurewebsites.net/notify")
		//   .build();

		// connection.start().then(function () {
		//   console.log('Connected!');
		// }).catch(function (err) {
		//   return console.error(err.toString());
		// });

		// connection.on("BroadcastMessage", (response: any) => {
		//   
		//   if (response.type === 'new') {
		//     var item = {
		//       RetroInfoDetailId: response.retroInfoDetailId,
		//       RetroInfoDetailAgilePointId: response.retroInfoDetailAgilePointId,
		//       RetroInfoDetailText: response.retroInfoDetailText,
		//       RetroInfoDetailTop: response.retroInfoDetailTop,
		//       RetroInfoDetailLeft: response.retroInfoDetailLeft,
		//       RetroInfoDetailImageCategoryId: response.retroInfoDetailImageCategoryId,
		//       RetroInfoDetailColor: response.retroInfoDetailColor,
		//     };
		//     this.doneList.push(item);

		//     const updateItem = this.todoList.find(this.findIndexToUpdateAgilePointDetails, response.retroInfoDetailAgilePointId);
		//     const index = this.todoList.indexOf(updateItem);
		//     if (index !== -1) {
		//       this.todoList.splice(index, 1);
		//     }
		//   } else {
		//     var item = {
		//       RetroInfoDetailId: response.retroInfoDetailId,
		//       RetroInfoDetailAgilePointId: response.retroInfoDetailAgilePointId,
		//       RetroInfoDetailText: response.retroInfoDetailText,
		//       RetroInfoDetailTop: response.retroInfoDetailTop,
		//       RetroInfoDetailLeft: response.retroInfoDetailLeft,
		//       RetroInfoDetailImageCategoryId: response.retroInfoDetailImageCategoryId,
		//       RetroInfoDetailColor: response.retroInfoDetailColor,
		//     };
		//     const updateItem = this.doneList.find(this.findIndexToUpdate, response.retroInfoDetailAgilePointId);
		//     const index = this.doneList.indexOf(updateItem);
		//     if (index !== -1) {
		//       this.doneList[index] = item;
		//     }
		//   }
		// });
	}

	showEdit() {
		alert('showEdit');
	}

	showDelete() {
		alert('showDelete');
	}

	dragMoved(event: any) {
		this.position = `> Position X: ${event.pointerPosition.x} - Y: ${event.pointerPosition.y
			}`;
	}

	allowDrop = (drag: any, drop: any) => {
		
		// add condition corrent div drag and drop item
	};

	getLetPosition(): any {
		return 150;
	}

	dragEndedNew(event: any, currentItem: any) {
		console.log(event.source.getFreeDragPosition());
		var currentElement = event.source.element.nativeElement;
		var style = window.getComputedStyle(currentElement);
		var matrix = new WebKitCSSMatrix(style.webkitTransform);

		// RetroInfoDetailTop: matrix.m42 + 155,
		// RetroInfoDetailLeft: matrix.m41 + 805,

		// RetroInfoDetailTop: 162,
		// RetroInfoDetailLeft: 310,

		var item = {
			RetroInfoDetailId: this.RetroInfoId,
			RetroInfoDetailAgilePointId: currentItem.AgilePointId,
			RetroInfoDetailText: currentItem.AgilePointText,
			RetroInfoDetailTop: matrix.m42 + 155,
			RetroInfoDetailLeft: matrix.m41 + 805,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailColor: "red",
			"Type": "new"
		};
		this.sendMessage(item);
	}

	dragEnded(event: any, currentItem: any) {
		var currentElement = event.source.element.nativeElement;
		var style = window.getComputedStyle(currentElement);
		var matrix = new WebKitCSSMatrix(style.webkitTransform);

		var item = {
			RetroInfoDetailId: this.RetroInfoId,
			RetroInfoDetailAgilePointId: currentItem.RetroInfoDetailAgilePointId,
			RetroInfoDetailText: currentItem.RetroInfoDetailText,
			RetroInfoDetailTop: matrix.m42,
			RetroInfoDetailLeft: matrix.m41,
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailColor: "red",
			"Type": "old"
		};
		this.sendMessage(item);
	}

	findIndexToUpdate(currentItem) {
		return currentItem.RetroInfoDetailAgilePointId === this;
	}

	findIndexToUpdateAgilePointDetails(currentItem) {
		return currentItem.AgilePointId === this;
	}

	sendMessage(item: any): void {
		var siteUrl = 'https://signalrservicehub.azurewebsites.net/Message';
		this.httpClientService.post(siteUrl, item).subscribe((response) => {
			console.log(response);
		}, error => {
			console.log(error);
		});
	}

	onItemDrop(e: any): boolean | undefined {
		if (this.retroInfo.retroinfo_status == true) {
			this.toasterService.pop("warning", "", "The retro meeting already completed not allowed to drag");
			return false;
		}
		if (this.imageCategoryModel === undefined || this.imageCategoryModel.ImageCategoryId === "") {
			this.toasterService.pop("warning", "", "Please select image category.");
			return false;
		}
		if (this.signalIRConnection == true) {
			if (this.droppedItemsList.length > this.ItemsListLength) {
				this.loadingAdd = false;
				this.GetRetroInfoDetails();
				if (this.imageCategoryModel) {
					this.imageCategoryDefault = this.imageCategoryModel.ImageCategoryId.toString();
				}
			}
		}

		var drag = e.nativeEvent;
		var topval = drag.layerY;
		var leftval = drag.layerX;
		var width = drag.srcElement.clientWidth;
		var height = drag.srcElement.clientHeight;

		let topperval = topval / height * 100;
		topperval = Math.round(topperval);
		let leftperval = leftval / width * 100;
		leftperval = Math.round(leftperval);

		if (leftperval > 85) {
			leftperval = 85;
		}

		if (topperval > 95) {
			topperval = 95;
		}

		if (this.droppedItemsList.indexOf(e.dragData) != -1) {
			// this.retroInfoDetails = new RetroInfoDetails(e.dragData.Id, this.RetroInfoId, e.dragData.Text, topperval.toString(), leftperval.toString(), this.imageCategoryModel.Id, this.imageCategoryModel.Color);
			// this.httpRetroInfoDetailService.updateRetroInfoDetails(this.retroInfoDetails).subscribe(
			// 	response => { this.onDragAndDropSuccess(); },
			// 	error => { this.loadingAdd = false; console.log(error); }
			// );

		} else {
			// this.retroInfoDetails = new RetroInfoDetails(0, this.RetroInfoId, e.dragData.Text, topperval.toString(), leftperval.toString(), this.imageCategoryModel.ImageCategoryId, this.imageCategoryModel.ImageCategoryColor);
			// this.httpRetroInfoDetailService.addRetroInfoDetails(this.retroInfoDetails).subscribe(
			// 	response => { this.addRetroObject(response); this.onDragAndDropSuccess() },
			// 	error => { this.loadingAdd = false; console.log(error); }
			// );
		}

		return undefined;
	}

	onDragAndDropSuccess() {
		this.signalIRConnection = true;
		this.ItemsListLength = this.droppedItemsList.length;
		this.loadingAdd = false;
	}

	onDropSelected(e: any): boolean | undefined {
		if (this.retroInfo.retroinfo_status == true) {
			this.toasterService.pop("warning", "", "The retro meeting already completed not allowed to drag");
			return false;
		}

		if (e.dragData) {
			// this.httpRetroInfoDetailService.deleteRetroInfoDetails(e.dragData.Id).subscribe(
			// 	response => {
			// 		
			// 		this.droppedItemsList = this.droppedItemsList.filter(function (el) {
			// 			return el.Id !== response.Id;
			// 		});
			// 		this.onDragAndDropSuccess()
			// 	},
			// 	error => { this.loadingAdd = false; console.log(error); }
			// );
		}

		return undefined;
	}

	addSave() {
		this.loadingAdd = true;
		// let agilePointDetails = new AgilePointDetails(0, this.Description, this.Description);
		// this.httpAgilePointService.addRetroPoints(agilePointDetails).subscribe(
		// 	response => { this.loadingAdd = false; this.addCancel(); },
		// 	error => { this.loadingAdd = false; console.log(error); }
		// );
	}

	onChangeImageCategory(selectedCategory) {
		if (selectedCategory.target.selectedIndex > 0) {
			this.imageCategoryModel = this.imageCategory[selectedCategory.target.selectedIndex - 1];
			this.imageCategoryDefault = this.imageCategoryModel.ImageCategoryId.toString();
		}
		else {
			this.imageCategoryDefault = "0";
			this.imageCategoryModel = new ImageCategory("", "", "", "", "");
		}
	}

	addCancel() {
		this.addShow = false;
		this.Description = '';
	}

	addNew() {
		this.addShow = true;
	}

	getBackgroundImageStyles() {
		let imageStyle = {
			'background-image': this.retroInfo ? 'url(' + this.retroInfo.retroinfo_imagepath + ')' : ''
		};
		return imageStyle;
	}

	GetRetroInfoDetails() {
		const getBookContent = this.httpRetroInfoDetailService.getRetroInfoModelId(this.RetroInfoId);
		const getBookDetail = this.httpRetroInfoDetailService.getRetroInfoModelId(this.RetroInfoId);

		this.spinner.hide();
		forkJoin([getBookDetail, getBookContent]).subscribe((response) => {
			
			this.spinner.hide();
			// this.retroInfo = new RetroInfo(1, true, "Test", "Test", "Test", "Test", "02-02-2021", "");
			this.droppedItemsList = [new RetroInfoDetails(1, 1, 1, "New Test f", "100", "100", 1, "Red", "Red", "Red")];
			this.agilePointDetails = [new AgilePointDetails(21, "New Test", "Test"),
			new AgilePointDetails(22, "New Test 2", "Test"),
			new AgilePointDetails(23, "New Test 3", "Test"),
			new AgilePointDetails(24, "New Test 4", "Test"),
			new AgilePointDetails(25, "New Test 5", "Test"),
			new AgilePointDetails(26, "New Test 6", "Test"),
			new AgilePointDetails(27, "New Test 7", "Test"),
			new AgilePointDetails(28, "New Test 8", "Test"),
			new AgilePointDetails(29, "New Test 9", "Test"),
			new AgilePointDetails(10, "New Test 22", "Test"),
			new AgilePointDetails(11, "New Test 33", "Test"),
			new AgilePointDetails(12, "New Test 44", "Test"),
			new AgilePointDetails(13, "New Test 45", "Test"),
			new AgilePointDetails(14, "New Test 6", "Test"),
			new AgilePointDetails(15, "New Test 76", "Test")];
			this.imageCategory = [new ImageCategory("1", "New Test", "Test", "Red", "Red")];
			this.ItemsListLength = this.droppedItemsList.length;
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	addRetroObject(response: any) {
		let ifExists = this.droppedItemsList.filter(a => a.RetroInfoDetailId === response.Id);
		if (ifExists.length == 0) {
			this.droppedItemsList.push(response);
		}
	}

	DownloadRetroMeeting() {

	}
}