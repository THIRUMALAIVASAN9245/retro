import {
  Component,
  OnInit,
  Input,
  forwardRef,
  HostBinding,
  NgZone, TemplateRef, Output, EventEmitter
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgilePointDetails } from '../models/agile-point-details';
import { RetroInfoDetails } from '../models/retro-info-details';
import { ImageCategory } from '../models/image-category';
import { ToasterService } from 'angular2-toaster';
import { HttpAgilePointService } from '../providers/services/agile-points.service';
import { RetroInfoService } from '../providers/services/retro-details.service';
import { forkJoin } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@aspnet/signalr';
import { HttpClientService } from '../providers/common/http-client.service';
import { environment } from 'src/environments/environment.prod';
import { DomSanitizer } from '@angular/platform-browser';
declare let html2canvas: any;
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import {
  animate,
  style,
  transition,
  trigger,
  state
} from "@angular/animations";
import { RetroFeedbackNote } from '../models/retro-feedback-note';

@Component({
  selector: 'editable-section',
  templateUrl: './editable-section.component.html',
  styleUrls: ['./editable-section.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => EditableSectionComponent),
      multi: true
    }
  ],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        overflow: 'hidden',
        height: '*',
        width: '350px'
      })),
      state('out', style({
        opacity: '0',
        overflow: 'hidden',
        height: '0px',
        width: '0px'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ])
  ]
})
export class EditableSectionComponent implements ControlValueAccessor {
  @Input() divStyle = { width: '70px' };
  @Input() editable = false;
  @Input() backgroundColors = null;
  @Input() showCommands = true;
  @Input() formDigestDetail = null;
  @Input() isDragAllow = false;
  @Output() deleteItemEmit = new EventEmitter<any>();
  @Output() disableCallEmit = new EventEmitter<any>();
  @Output() updateAgreeAndDisAgreeEmit = new EventEmitter<any>();
  @Input() name = null;
  @Input() retroTracker: any = [];
  @Input() retroInfo = null;
  disabled = false;
  retroNote: any = [];
  retroTrackerAgree: any = [];
  retroTrackerDisAgree: any = [];
  color;
  modalRef: BsModalRef;
  currentAction = null;
  previousAction = null;
  currentItem = null;
  helpMenuOpen: string;

  get opacity() {
    return this.disabled ? 0.25 : 1;
  }

  model = {
    content: { text: '' },
    background: '#FFFFFF',
    ImageCategoryFontColor: "black",
    RetroInfoDetailId: 0,
    RetroInfoDetailTop: 0,
    RetroInfoDetailLeft: 0
  };
  onChange = (rating: any) => { };
  onTouched = () => { };
  baseUrl = environment.apiBaseUrl;

  constructor(private route: ActivatedRoute,
    private httpClient: HttpClient,
    private router: Router,
    private zone: NgZone,
    private sanitizer: DomSanitizer,
    private httpClientService: HttpClientService,
    private spinner: NgxSpinnerService,
    private toasterService: ToasterService,
    private modalService: BsModalService,
    private httpAgilePointService: HttpAgilePointService,
    private httpRetroInfoDetailService: RetroInfoService) { }

  ngOnInit() {
    this.helpMenuOpen = 'out';
    this.retroTrackerAgree = this.retroTracker.filter(c => c.AgreeOrDisAgree == "Agree");
    this.retroTrackerDisAgree = this.retroTracker.filter(c => c.AgreeOrDisAgree == "DisAgree");
  }

  writeValue(value: any): void {
    this.model = value;
  }

  registerOnChange(fn: (rating: number) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
    this.editable = !isDisabled;
  }

  modelChanged(modelPatch) {
    this.model = { ...this.model, ...modelPatch };
    this.onChange(this.model);
  }

  contentChanged(v) {
    this.model = { ...this.model, content: v };
    this.onChange(this.model);
  }

  /** Editor Commands **/
  bold() {
    document.execCommand('bold', false, '');
  }

  italic() {
    document.execCommand('italic', false, '');
  }

  link() {
    var url = prompt('Enter the URL');
    document.execCommand('createLink', false, url);
  }

  changeColor(color) {
    document.execCommand('foreColor', false, color);
  }

  dragEnded(event: any, currentItem: any) {
    var currentElement = event.source.element.nativeElement;
    var style = window.getComputedStyle(currentElement);
    var matrix = new WebKitCSSMatrix(style.webkitTransform);

    this.model = { ...this.model, RetroInfoDetailLeft: matrix.m41, RetroInfoDetailTop: matrix.m42 };
    this.onChange(this.model);

    var item = {
      RetroInfoDetailId: this.model.RetroInfoDetailId,
      RetroInfoDetailText: this.model.content.text,
      RetroInfoDetailTop: matrix.m42,
      RetroInfoDetailLeft: matrix.m41,
      RetroInfoDetailColor: this.model.background,
      ImageCategoryFontColor: this.model.ImageCategoryFontColor
    };
    // this.sendMessage(item);
    this.updateRetroInfoDetailDetail(item);
  }

  updateRetroInfoDetailDetail(currentItem) {
    this.spinner.show();
    let listLibraryBookDetailsName = "RetroInfoDetail";
    var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
    var item = {
      "__metadata": { "type": itemlistLibraryBookDetailsNameType },
      RetroInfoDetailText: currentItem.RetroInfoDetailText,
      RetroInfoDetailTop: String(currentItem.RetroInfoDetailTop),
      RetroInfoDetailLeft: String(currentItem.RetroInfoDetailLeft),
      RetroInfoDetailColor: currentItem.RetroInfoDetailColor,
      ImageCategoryFontColor: currentItem.ImageCategoryFontColor
    };

    var siteBookUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items(" + currentItem.RetroInfoDetailId + ")";

    let getBookDetail = this.httpClientService.httpMerge(siteBookUrl, item, this.formDigestDetail.FormDigestValue);

    forkJoin([getBookDetail]).subscribe((responce) => {
      this.spinner.hide();
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }

  getItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
  }

  saveItem() {
    var item = {
      RetroInfoDetailId: this.model.RetroInfoDetailId,
      RetroInfoDetailTop: this.model.RetroInfoDetailTop,
      RetroInfoDetailLeft: this.model.RetroInfoDetailLeft,
      RetroInfoDetailText: this.model.content.text,
      RetroInfoDetailColor: this.model.background,
      ImageCategoryFontColor: this.model.ImageCategoryFontColor
    };
    // this.sendMessage(item);
    this.updateRetroInfoDetailDetail(item);
    this.editable = !this.editable;
    const disableItem = {
      RetroInfoDetailId: this.model.RetroInfoDetailId,
      editable: false
    };
    this.disableCallEmit.emit(disableItem);
  }

  deleteItem(model: any) {
    this.deleteItemEmit.emit(model.RetroInfoDetailId);
  }

  itemEdit() {
    this.editable = !this.editable;
    const disableItem = {
      RetroInfoDetailId: this.model.RetroInfoDetailId,
      editable: true
    };
    this.disableCallEmit.emit(disableItem);
  }

  addLike(template: TemplateRef<any>) {
    if (this.name != null && this.name != "") {
      var res = this.retroTracker.filter(c => c.AgreeOrDisAgree == "Agree" && c.Name == this.name);
      if (res.length > 0) {
        return;
      }
      else if (res.length == 0) {
        var resDis = this.retroTracker.filter(c => c.AgreeOrDisAgree == "DisAgree" && c.Name == this.name);
        if (resDis.length > 0) {
          this.currentAction = "Agree";
          this.previousAction = "DisAgree";
          this.currentItem = resDis[0];
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        } else {
          this.addLikeAndDisLikeMethod("Agree");
        }
      }
    } else {
      // this.toasterService.pop("warning", "", "Please select or enter your name");
    }
  }

  addDisLike(template: TemplateRef<any>) {
    if (this.name != null && this.name != "") {
      var res = this.retroTracker.filter(c => c.AgreeOrDisAgree == "DisAgree" && c.Name == this.name);
      if (res.length > 0) {
        return;
      } else if (res.length == 0) {
        var resDis = this.retroTracker.filter(c => c.AgreeOrDisAgree == "Agree" && c.Name == this.name);
        if (resDis.length > 0) {
          this.currentAction = "DisAgree";
          this.previousAction = "Agree";
          this.currentItem = resDis[0];
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        } else {
          this.addLikeAndDisLikeMethod("DisAgree");
        }
      }
    } else {
      // this.toasterService.pop("warning", "", "Please select or enter your name");
    }
  }

  private addLikeAndDisLikeMethod(agreeOrDisAgree: string) {
    this.spinner.show();
    let listRetroTrackerName = "RetroTracker";
    var itemlistRetroTrackerType = this.getItemTypeForListName(listRetroTrackerName);
    var item = {
      "__metadata": { "type": itemlistRetroTrackerType },
      RetroDetailId: this.model.RetroInfoDetailId,
      RetroInfoId: this.retroInfo.retroinfo_id,
      TeamId: this.retroInfo.retroinfo_projectinfo_id,
      Name: this.name,
      AgreeOrDisAgree: agreeOrDisAgree
    };

    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listRetroTrackerName + "')/items";

    this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
      this.spinner.hide();
      const newBookId = responce && responce.d && responce.d.ID;
      this.updateAgreeAndDisAgreeEmit.emit(newBookId);
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }

  confirm(): void {
    this.modalRef.hide();
    this.likeAndDisLikeUpdate();
  }

  decline(): void {
    this.modalRef.hide();
  }

  private likeAndDisLikeUpdate() {
    debugger;
    this.spinner.show();
    let listRetroTrackerName = "RetroTracker";
    var itemlistRetroTrackerType = this.getItemTypeForListName(listRetroTrackerName);
    var item = {
      "__metadata": { "type": itemlistRetroTrackerType },
      RetroDetailId: this.model.RetroInfoDetailId,
      RetroInfoId: this.retroInfo.retroinfo_id,
      TeamId: this.retroInfo.retroinfo_projectinfo_id,
      Name: this.name,
      AgreeOrDisAgree: this.currentAction
    };

    var siteBookUrl = this.baseUrl + "_api/lists/getbytitle('" + listRetroTrackerName + "')/items(" + this.currentItem.Id + ")";
    let mergeReq = this.httpClientService.httpMerge(siteBookUrl, item, this.formDigestDetail.FormDigestValue);

    forkJoin([mergeReq]).subscribe((responce) => {
      this.spinner.hide();
      this.updateAgreeAndDisAgreeEmit.emit(this.model.RetroInfoDetailId);
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }

  toggleHelpMenu(): void {
    debugger;
    this.helpMenuOpen = this.helpMenuOpen === 'out' ? 'in' : 'out';

    if (this.helpMenuOpen == 'in') {
      this.getRetroFeedbackNote();
    }
  }

  private getRetroFeedbackNote() {
    debugger;
    const retroFeedbackNoteById = this.httpRetroInfoDetailService.getRetroFeedbackNoteById(this.model.RetroInfoDetailId);
    forkJoin([retroFeedbackNoteById]).subscribe((response) => {
      this.spinner.hide();
      this.retroNote = response[0];
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }

  sendMessage() {
    if (this.name != null && this.name != "" && this.messageItem != null && this.messageItem != "") {
      this.spinner.show();
      let listRetroTrackerName = "RetroFeedbackNote";
      var itemlistRetroTrackerType = this.getItemTypeForListName(listRetroTrackerName);
      var item = {
        "__metadata": { "type": itemlistRetroTrackerType },
        RetroDetailId: this.model.RetroInfoDetailId,
        RetroInfoId: this.retroInfo.retroinfo_id,
        Name: this.name,
        FeedbackNote: this.messageItem
      };

      var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listRetroTrackerName + "')/items";

      this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
        this.spinner.hide();
        const retroFeedbackNoteId = responce && responce.d && responce.d.ID;
        debugger;
        this.getRetroFeedbackNote();
        this.messageItem = '';
      }, error => {
        this.spinner.hide();
        console.log(error);
      });
    }
  }

  messageItem = '';
}