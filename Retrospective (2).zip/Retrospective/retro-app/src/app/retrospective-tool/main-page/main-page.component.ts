import { Component, ElementRef, OnInit, ViewChild, NgZone, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgilePointDetails } from '../models/agile-point-details';
import { RetroInfoDetails } from '../models/retro-info-details';
import { ImageCategory } from '../models/image-category';
import { ToasterService } from 'angular2-toaster';
import { HttpAgilePointService } from '../providers/services/agile-points.service';
import { RetroInfoService } from '../providers/services/retro-details.service';
import { forkJoin } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@aspnet/signalr';
import { HttpClientService } from '../providers/common/http-client.service';
import { environment } from 'src/environments/environment.prod';
import { DomSanitizer } from '@angular/platform-browser';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
declare let html2canvas: any;
import { distinct } from 'rxjs/operators';
import {
  animate,
  style,
  transition,
  trigger,
  state
} from "@angular/animations";

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        overflow: 'hidden',
        height: '*',
        width: '350px'
      })),
      state('out', style({
        opacity: '0',
        overflow: 'hidden',
        height: '0px',
        width: '0px'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ])
  ]
})
export class MainPageComponent implements OnInit {

  public loadingAdd;
  public agilePointDetails: AgilePointDetails[];
  public imageCategory: ImageCategory[];
  public retroInfoDetails: RetroInfoDetails;
  position = "";
  state = "";
  public RetroInfoId;
  public droppedItemsList: RetroInfoDetails[] = [];
  public filterValue: string = '';
  public imageCategoryDefault = '0';
  public imageCategoryModel: ImageCategory;
  signalIRConnection = false;
  ItemsListLength: number;
  formDigestDetail: any;
  baseUrl = environment.apiBaseUrl;
  retroInfo;
  todoList: any[] = [];
  tiles: any[] = [];
  modalRef: BsModalRef;
  modalRefView: BsModalRef;
  modalRefCat: BsModalRef;
  modalRefCatView: BsModalRef;
  config = {
    ariaDescribedby: 'my-modal-description',
    ariaLabelledBy: 'my-modal-title',
    class: 'modal-lg',
    backdrop: true,
    ignoreBackdropClick: true
  };

  Description: string = '';
  RetrospectivePointsCode: string = '';
  RetrospectivePointsText: string = '';

  ImageCategoryCode: string = '';
  ImageCategoryText: string = '';
  BackgroundColor: string = '#2889e9';
  FontColor: string = '#59caa0';
  backgroundUrl;
  helpMenuOpen: string;

  constructor(private route: ActivatedRoute,
    private httpClient: HttpClient,
    private router: Router,
    private zone: NgZone,
    private sanitizer: DomSanitizer,
    private httpClientService: HttpClientService,
    private spinner: NgxSpinnerService,
    private toasterService: ToasterService,
    private modalService: BsModalService,
    private httpAgilePointService: HttpAgilePointService,
    private httpRetroInfoDetailService: RetroInfoService) {
  }

  ngOnInit(): void {
    this.helpMenuOpen = 'out';
    // this.getBackgroundUrl();
    // this.getFormDigest();
    // this.RetroInfoId = 13;
    // this.spinner.show();
    // const getRetroInfoById = this.httpRetroInfoDetailService.getRetroInfoModelId(this.RetroInfoId);
    // const getRetroInfoDetailById = this.httpRetroInfoDetailService.getRetroInfoDetailByIdLatest(this.RetroInfoId);
    // const getRetroAgilePointDetail = this.httpRetroInfoDetailService.getRetroAgilePointDetail();

    // forkJoin([getRetroInfoDetailById, getRetroAgilePointDetail, getRetroInfoById]).subscribe((response) => {
    //   this.spinner.hide();
    //   console.log(response);
    //   this.tiles = response[0];
    //   var todoList = response[1];
    //   this.todoList = todoList.filter(item => !this.tiles.some(other => item.AgilePointId == other.tile.RetroInfoDetailAgilePointId));
    //   this.retroInfo = response[2];
    //   this.getBackgroundUrl();
    //   this.getRetroListDetails(this.retroInfo.retroinfo_image_id);
    // }, error => {
    //   this.spinner.hide();
    //   console.log(error);
    // });

    var colors = [
      { name: 'Red', value: '#ff1744', foreground: 'white' },
      { name: 'Pink', value: '#ff80ab', foreground: 'black' },
      { name: 'Purple', value: '#d500f9', foreground: 'white' },
      { name: 'Deep Purple', value: '#7c4dff', foreground: 'white' },
      { name: 'Indigo', value: '#3d5afe', foreground: 'white' },
      { name: 'Blue', value: '#2979ff', foreground: 'white' },
      { name: 'Light Blue', value: '#00b0ff', foreground: 'black' },
      { name: 'Cyan', value: '#00e5ff', foreground: 'black' },
      { name: 'Teal', value: '#1de9b6', foreground: 'black' },
      { name: 'Green', value: '#00e676', foreground: 'black' },
      { name: 'Light Green', value: '#76ff03', foreground: 'black' },
      { name: 'Lime', value: '#c6ff00', foreground: 'black' },
      { name: 'Yellow', value: '#ffea00', foreground: 'black' },
      { name: 'Amber', value: '#ffc400', foreground: 'black' },
      { name: 'Orange', value: '#ff9100', foreground: 'black' },
      { name: 'Deep Orange', value: '#ff3d00', foreground: 'white' },
      { name: 'Brown', value: '#8d6e63', foreground: 'white' },
      { name: 'Light Gray', value: '#bdbdbd', foreground: 'black' },
      { name: 'Dark Gray', value: '#616161', foreground: 'white' },
      { name: 'Blue Gray', value: '#78909c', foreground: 'white' }
    ];

    const retroTrackerNameList = colors.map(person => person.foreground);
    console.log(retroTrackerNameList);
  }

  toggleHelpMenu(): void {
    this.helpMenuOpen = this.helpMenuOpen === 'out' ? 'in' : 'out';
  }

  messages = [];

  // tilesd = Array.from({ length: 6 }, () => ({
  //   editable: false,
  //   tile: {
  //     content: {
  //       text: 'Angular Rocks !!',
  //       html: '<i>Angular </i><b>Rocks !!</b>'
  //     },
  //     background: '#2ecc71',
  //   }
  // }));

  tiless: any[] = [
    {
      editable: false,
      tile: {
        content: {
          text: 'Angular Rocks !! 1'
        },
        background: '#2ecc71',
        RetroInfoId: 1,
        RetroInfoDetailId: 1,
        RetroInfoDetailAgilePointId: 1,
        RetroInfoDetailText: "Takexcvxcvxcvxcvxcvxcvxcvxcv a showerxcvxcvxcvxcv  Take a showerTakexcvxcvxcvxcvxcvxcvxcvxcv a shower",
        RetroInfoDetailTop: 195.898,
        RetroInfoDetailLeft: -27.2634,
        RetroInfoDetailImageCategoryId: 1,
        RetroInfoDetailImageCategoryName: "red tswet",
        RetroInfoDetailColor: "red"
      }
    },
    {
      editable: false,
      tile: {
        content: {
          text: 'Angular Rocks !!'
        },
        background: '#2ecc71',
        RetroInfoId: 1,
        RetroInfoDetailId: 1,
        RetroInfoDetailAgilePointId: 2,
        RetroInfoDetailText: " Takexcvxcvxcvxcvxcvxcvxcvxcv a showerxcvxcvxcvxcv  Take a showerTakexcvxcvxcvxcv ashower Take ashowerTake a showerTake a shower Take a shower  Take a showerTake a shower",
        RetroInfoDetailTop: 180,
        RetroInfoDetailLeft: 40,
        RetroInfoDetailImageCategoryId: 1,
        RetroInfoDetailImageCategoryName: "red tswet",
        RetroInfoDetailColor: "green"
      },
    },
    {
      editable: false,
      tile: {
        content: {
          text: 'Angular Rocks !!'
        },
        background: '#2ecc71',
        RetroInfoId: 1,
        RetroInfoDetailId: 1,
        RetroInfoDetailAgilePointId: 3,
        RetroInfoDetailText: "Takexcvxcvxcvxcvxcvxcvxcvxcv a shower  Take a showerTake a shower Take a shower  Take a showerTake a shower",
        RetroInfoDetailTop: 150,
        RetroInfoDetailLeft: 70,
        RetroInfoDetailImageCategoryId: 1,
        RetroInfoDetailImageCategoryName: "red tswet",
        RetroInfoDetailColor: "blue"
      },
    },
    {
      editable: false,
      tile: {
        content: {
          text: 'Angular Rocks !!'
        },
        background: '#2ecc71',
        RetroInfoId: 1,
        RetroInfoDetailId: 1,
        RetroInfoDetailAgilePointId: 4,
        RetroInfoDetailText: "Takexcvxcvxcvxcvxcvxcvxcvxcv a shower  Take a showerTake a shower",
        RetroInfoDetailTop: 26,
        RetroInfoDetailLeft: 30,
        RetroInfoDetailImageCategoryId: 1,
        RetroInfoDetailImageCategoryName: "red tswet",
        RetroInfoDetailColor: "lightgreen"
      },
    },
    {
      editable: false,
      tile: {
        content: {
          text: 'Angular Rocks !!'
        },
        background: '#2ecc71',
        RetroInfoId: 1,
        RetroInfoDetailId: 1,
        RetroInfoDetailAgilePointId: 5,
        RetroInfoDetailText: "Walkxcvxcvxcvxcvxcvxcvxcvxcv Take a shower  Take a shower",
        RetroInfoDetailTop: 130,
        RetroInfoDetailLeft: 40,
        RetroInfoDetailImageCategoryId: 1,
        RetroInfoDetailImageCategoryName: "red tswet",
        RetroInfoDetailColor: "skublue"
      }
    }
  ];

  showEdit() {
    const newItem = {
      editable: false,
      tile: {
        content: {
          text: 'Angular Take a shower !!'
        },
        background: '#2ecc71',
        RetroInfoId: 1,
        RetroInfoDetailId: 1,
        RetroInfoDetailAgilePointId: 5,
        RetroInfoDetailText: "Take a shower  Take a shower",
        RetroInfoDetailTop: 40,
        RetroInfoDetailLeft: 40,
        RetroInfoDetailImageCategoryId: 1,
        RetroInfoDetailImageCategoryName: "red tswet",
        RetroInfoDetailColor: "skublue"
      }
    };

    this.tiles.push(newItem);
  }

  getBackgroundUrl() {
    if (this.retroInfo && this.retroInfo.retroinfo_imageBase64) {
      var imageBase64 = this.retroInfo.retroinfo_imageBase64.split('>');
      var imageBaseImageData = imageBase64[1];
      var imageBase = imageBaseImageData.replace('</div', '');
      // var res = this.retroInfo.retroinfo_imageBase64.replace(/^<div[^>]*>|<\/div>$/g, '');
      this.backgroundUrl = "data:image/png;base64," + imageBase;
    }
  }

  getFormDigest() {
    this.spinner.show();
    this.httpClientService.getFormDigest().subscribe((response: Response) => {
      this.spinner.hide();
      this.formDigestDetail = response;
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }
  isOpen = true;
  checkIsOpen() {
    if (this.selectedItemVal != "") {
      return false;
    }
    return true;
  }

  selectEvent(item) {
    if (this.selectedItemVal != "") {
      this.isOpen = false;
    } else {
      this.isOpen = true;
    }
  }

  onChangeSearch(val: string) {
    if (this.selectedItemVal != "") {
      this.isOpen = false;
    } else {
      this.isOpen = true;
    }
  }

  onFocused(e) {
    this.isOpen = true;
  }

  closed(e) {
    if (this.selectedItemVal != "") {
      this.isOpen = false;
    } else {
      this.isOpen = true;
    }
  }

  opened(e) {
    this.isOpen = true;
  }

  getRetroListDetails(imageCategoryId) {
    this.spinner.show();
    this.httpRetroInfoDetailService.getImageCategoryDetail(imageCategoryId).subscribe(model => {

      this.imageCategory = model;
      this.spinner.hide();
    });
  }

  sendMessage() {
    
  }

  placeholder: string = 'Enter the Country Name';
  keyword = 'name';
  selectedItemVal = "";
  countriesTemplate = ['Albania', 'Andorra', 'Armenia', 'Austria', 'Azerbaijan', 'Belarus',
    'Belgium', 'Bosnia & Herzegovina', 'Bulgaria', 'Croatia', 'Cyprus',
    'Czech Republic', 'Denmark', 'Estonia', 'Finland', 'France', 'Georgia',
    'Germany', 'Greece', 'Hungary', 'Iceland', 'India', 'Ireland', 'Italy', 'Kosovo',
    'Latvia', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macedonia', 'Malta',
    'Moldova', 'Monaco', 'Montenegro', 'Netherlands', 'Norway', 'Poland',
    'Portugal', 'Romania', 'Russia', 'San Marino', 'Serbia', 'Slovakia', 'Slovenia',
    'Spain', 'Sweden', 'Switzerland', 'Turkey', 'Ukraine', 'United Kingdom', 'Vatican City'];
}