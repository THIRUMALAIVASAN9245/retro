import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { RetroInfoService } from '../providers/services/retro-details.service';
import { IRetroInfoModel } from '../models/retro-info.model';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClientService } from '../providers/common/http-client.service';
import { environment } from 'src/environments/environment.prod';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-retro-meeting-list',
  templateUrl: './retro-meeting-list.component.html',
  styleUrls: ['./retro-meeting-list.component.scss']
})
export class RetroSummaryComponent implements OnInit {
  retroInfoDetail: IRetroInfoModel[] = [];
  currentPage: number = 0;
  currentItemId: number = 0;
  totalItems: number;
  modalRef: BsModalRef;
  config = {
    ariaDescribedby: 'my-modal-description',
    ariaLabelledBy: 'my-modal-title',
    class: 'modal-lg',
    backdrop: true,
    ignoreBackdropClick: true
  };
  formDigestDetail: any;
  public itemsPath;
  imageObject: any;
  public items: any;
  baseUrl = environment.apiBaseUrl;
  retroForm: FormGroup;
  public imageIndex = 0;
  public retroInfoData: any[];
  public projects: any[];
  projectsItem: any;
  public searchProjectId: number;

  constructor(private retroInfoService: RetroInfoService,
    private router: Router,
    private httpClientService: HttpClientService,
    private modalService: BsModalService,
    public datepipe: DatePipe,
    private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.getFormDigest();
    this.getRetroListDetails();
    this.getRetroImageDetails();
    this.retroForm = new FormGroup({
      RetroName: new FormControl(null, [Validators.required]),
      Sprint: new FormControl(null, [Validators.required]),
      Project: new FormControl("", [Validators.required])
    });
    this.getRetroTeamDetails();
    // this.projects = [
    //   {
    //     Id: 1,
    //     Project: 'my-modal 1'
    //   },
    //   {
    //     Id: 2,
    //     Project: 'my-modal 12'
    //   }
    // ];
  }

  onChange(newValue) {

    console.log(newValue);
    this.projectsItem = this.projects.filter(c => c.Id == newValue);
  }

  onSubmit() {

    this.spinner.show();
    let listLibraryBookDetailsName = "RetroInfoModel";
    var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
    const date = new Date();
    let latest_date = this.datepipe.transform(date, 'dd-MM-yyyy');
    var item = {
      "__metadata": { "type": itemlistLibraryBookDetailsNameType },
      RetroinfoName: this.retroForm.value.RetroName,
      RetroinfoProjectInfoId: String(this.projectsItem[0].Id),
      RetroinfoProjectInfoName: this.projectsItem[0].Project,
      RetroinfoSprint: String(this.retroForm.value.Sprint),
      RetroinfoDate: latest_date,
      RetroinfoImageBase64: this.items.image.replace('data:image/png;base64,', ''),
      RetroinfoStatus: "New",
      RetroinfoImageId: String(this.items.ImageInfoId)
    };

    var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items";

    this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
      this.spinner.hide();
      const newBookId = responce && responce.d && responce.d.ID;
      console.log(newBookId);
      this.modalRef.hide();
      this.getRetroListDetails();
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }

  getItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
  }

  pageChanged(event: any): void {
    this.currentPage = event.page - 1;
    this.getRetroListDetails();
  }

  addNew(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, this.config);
  }

  imageClickHandler(e) {
    this.imageIndex = e;
    this.items = this.imageObject[e];
  }

  private getRetroListDetails() {
    this.spinner.show();
    const startItem = this.currentPage * 10;
    this.retroInfoService.getRetroInfo(startItem, this.currentItemId).subscribe(model => {
      this.retroInfoDetail = model.RetroInfoDetail;
      this.totalItems = model.count;
      this.currentItemId = +this.retroInfoDetail[this.retroInfoDetail.length - 1].retroinfo_id;
      this.spinner.hide();
    });
  }

  private getRetroImageDetails() {
    this.spinner.show();
    this.retroInfoService.getRetroImageDetail().subscribe(model => {
      this.imageObject = model;
      this.spinner.hide();
    });
  }

  private getRetroTeamDetails() {
    this.spinner.show();
    this.retroInfoService.getRetroTeamDetail().subscribe(model => {
      this.projects = model;
      this.spinner.hide();
    });
  }

  getFormDigest() {
    this.spinner.show();
    this.httpClientService.getFormDigest().subscribe((response: Response) => {
      this.spinner.hide();
      this.formDigestDetail = response;
    }, error => {
      this.spinner.hide();
      console.log(error);
    });
  }
}