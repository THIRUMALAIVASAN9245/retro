﻿import { Component, OnInit, NgZone, TemplateRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgilePointDetails } from '../models/agile-point-details';
import { RetroInfoDetails } from '../models/retro-info-details';
import { ImageCategory } from '../models/image-category';
import { ToasterService } from 'angular2-toaster';
import { HttpAgilePointService } from '../providers/services/agile-points.service';
import { RetroInfoService } from '../providers/services/retro-details.service';
import { forkJoin, interval, of, Subscription } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient } from '@angular/common/http';
import * as signalR from '@aspnet/signalr';
import { HttpClientService } from '../providers/common/http-client.service';
import { environment } from 'src/environments/environment.prod';
import { DomSanitizer } from '@angular/platform-browser';
declare let html2canvas: any;
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { HttpRequest, HubConnection, HubConnectionBuilder, IHttpConnectionOptions, JsonHubProtocol } from '@aspnet/signalr';
import { distinct } from 'rxjs/operators';

/**
 * @component
 * @description
 * This component add new weekly status report details for particular week
*/
@Component({
	selector: 'retrospective-meeting-details',
	templateUrl: './retrospective-meeting-details.component.html',
	styleUrls: ['./retrospective-meeting.scss']
})

export class RetrospectiveMeetingDetailsComponent implements OnInit, OnDestroy {
	public agilePointDetails: AgilePointDetails[];
	public imageCategory: ImageCategory[];
	public retroInfoDetails: RetroInfoDetails;
	position = "";
	state = "";
	public RetroInfoId;
	public filterValue: string = '';
	public imageCategoryDefault = '0';
	public imageCategoryModel: ImageCategory;
	signalIRConnection = false;
	ItemsListLength: number;
	formDigestDetail: any;
	baseUrl = environment.apiBaseUrl;
	retroInfo;
	todoList: any[] = [];
	doneList: any[] = [];
	doneListDisable: any[] = [];
	modalRef: BsModalRef;
	modalRefView: BsModalRef;
	modalRefCat: BsModalRef;
	modalRefCatView: BsModalRef;
	config = {
		ariaDescribedby: 'my-modal-description',
		ariaLabelledBy: 'my-modal-title',
		class: 'modal-lg',
		backdrop: true,
		ignoreBackdropClick: true
	};

	Description: string = '';
	RetrospectivePointsCode: string = '';
	RetrospectivePointsText: string = '';
	selectedItemVal: any = "";
	ImageCategoryCode: string = '';
	ImageCategoryText: string = '';
	BackgroundColor: string = '#2889e9';
	FontColor: string = '#59caa0';
	backgroundUrl;
	mySubscription: Subscription;
	retroTrackerInfo: any = [];
	retroFeedbackNote: any = [];
	isOpen = true;

	/**
	 * Constructor for RetrospectiveMeetingDetailsComponent class
	 * @param route
	 * @param router
	 * @param HttpAgilePointService
	*/
	constructor(private route: ActivatedRoute,
		private httpClient: HttpClient,
		private router: Router,
		private zone: NgZone,
		private sanitizer: DomSanitizer,
		private httpClientService: HttpClientService,
		private spinner: NgxSpinnerService,
		private toasterService: ToasterService,
		private modalService: BsModalService,
		private httpAgilePointService: HttpAgilePointService,
		private httpRetroInfoDetailService: RetroInfoService) {
	}

	/**
	 * @override OnInit
	*/
	ngOnInit() {
		this.imageCategoryDefault = "0";
		this.getBackgroundUrl();
		this.getFormDigest();
		this.RetroInfoId = Number(this.route.snapshot.params['retroInfoId']);

		this.spinner.show();
		const getRetroInfoById = this.httpRetroInfoDetailService.getRetroInfoModelId(this.RetroInfoId);
		const getRetroInfoDetailById = this.httpRetroInfoDetailService.getRetroInfoDetailByIdLatest(this.RetroInfoId);
		const getRetroAgilePointDetail = this.httpRetroInfoDetailService.getRetroAgilePointDetail();
		const retroTrackerInfoMyId = this.httpRetroInfoDetailService.getRetroTrackerById(this.RetroInfoId);
		const retroFeedbackNoteById = this.httpRetroInfoDetailService.getRetroFeedbackNoteById(this.RetroInfoId);
		forkJoin([getRetroInfoDetailById, getRetroAgilePointDetail, getRetroInfoById, retroTrackerInfoMyId]).subscribe((response) => {
			this.spinner.hide();
			this.doneList = response[0];
			this.doneListDisable = response[0];
			var todoList = response[1];
			this.todoList = todoList.filter(item => !this.doneList.some(other => item.AgilePointId == other.tile.RetroInfoDetailAgilePointId));
			this.retroInfo = response[2];
			this.retroTrackerInfo = response[3];
			// this.retroFeedbackNote = response[4];
			this.getBackgroundUrl();
			this.getRetroListDetails(this.retroInfo.retroinfo_image_id);
			this.getTeamNameDetails(this.retroInfo.retroinfo_projectinfo_id);
		}, error => {
			this.spinner.hide();
			console.log(error);
		});

		this.mySubscription = interval(100000).subscribe((x => {
			const res = this.doneListDisable.find(v => v.editable == true);
			if (!res) {
				this.evetWatcherUnTill();
			}
		}));
	}

	evetWatcherUnTill() {
		const getRetroInfoDetailById = this.httpRetroInfoDetailService.getRetroInfoDetailByIdLatest(this.RetroInfoId);
		const getRetroAgilePointDetail = this.httpRetroInfoDetailService.getRetroAgilePointDetail();
		const getRetroInfoById = this.httpRetroInfoDetailService.getRetroInfoModelId(this.RetroInfoId);
		const retroTrackerInfoMyId = this.httpRetroInfoDetailService.getRetroTrackerById(this.RetroInfoId);
		const retroFeedbackNoteById = this.httpRetroInfoDetailService.getRetroFeedbackNoteById(this.RetroInfoId);
		forkJoin([getRetroInfoDetailById, getRetroAgilePointDetail, getRetroInfoById, retroTrackerInfoMyId]).subscribe((response) => {
			this.spinner.hide();
			this.doneList = response[0];
			this.doneListDisable = response[0];
			var todoList = response[1];
			this.todoList = todoList.filter(item => !this.doneList.some(other => item.AgilePointId == other.tile.RetroInfoDetailAgilePointId));
			var retroInfo = response[2];
			this.retroTrackerInfo = response[3];
			// this.retroFeedbackNote = response[4];
			this.getTeamNameDetails(this.retroInfo.retroinfo_projectinfo_id);
			if (retroInfo.retroinfo_status === 'View') {
				this.mySubscription.unsubscribe();
			}
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	ngOnDestroy() {
		this.mySubscription.unsubscribe();
	}

	goBack() {
		this.mySubscription.unsubscribe();
		this.router.navigate(['/retrospective-meeting-details']); // navigate to other page
	}

	disableCallEmit(item: any) {
		if (item) {
			const id = item.RetroInfoDetailId;
			let obj = this.doneListDisable.find(f => f.tile.RetroInfoDetailId == id);
			if (obj) {
				obj.editable = item.editable;
			}
		}
	}

	getRetroListDetails(imageCategoryId) {
		this.spinner.show();
		this.httpRetroInfoDetailService.getImageCategoryDetail(imageCategoryId).subscribe(model => {
			this.imageCategory = model;
			this.spinner.hide();
		});
	}

	dragMoved(event: any) {
		console.log(this.position = `> Position X: ${event.pointerPosition.x} - Y: ${event.pointerPosition.y}`);
	}

	isDragAllowRetro(): boolean {
		if (this.retroInfo.retroinfo_status === "New") {
			return false;
		}
		return true;
	}

	isDragAllow(): boolean {
		if (this.retroInfo.retroinfo_status === "New" && this.imageCategoryDefault != "0") {
			return false;
		}

		return true;
	}

	addNewDiv(template: TemplateRef<any>) {
		if (this.retroInfo.retroinfo_status === "View") {
			return false;
		} else {
			if (this.imageCategoryDefault != "0" && this.filterValue != "") {
				let newItem = this.doneList[0];
				newItem.RetroInfoDetailText = this.filterValue;

				var item = {
					RetroInfoDetailAgilePointId: newItem.RetroInfoDetailAgilePointId,
					RetroInfoDetailText: newItem.RetroInfoDetailText,
					RetroInfoDetailTop: newItem.RetroInfoDetailTop,
					RetroInfoDetailLeft: newItem.RetroInfoDetailLeft
				};

				this.addNewRetroInfoDetail(item);
				this.filterValue = "";
			}
			else {
				this.modalRef = this.modalService.show(template, this.config);
			}
		}
	}

	dragEndedNew(event: any, currentItem: any) {
		var currentElement = event.source.element.nativeElement;
		var style = window.getComputedStyle(currentElement);
		var matrix = new WebKitCSSMatrix(style.webkitTransform);

		// RetroInfoDetailTop: matrix.m42 + 155,
		// RetroInfoDetailLeft: matrix.m41 + 805,
		// RetroInfoDetailTop: 162,
		// RetroInfoDetailLeft: 310,

		var item = {
			RetroInfoDetailAgilePointId: currentItem.AgilePointId,
			RetroInfoDetailText: currentItem.AgilePointText,
			RetroInfoDetailTop: matrix.m42 + 155,
			RetroInfoDetailLeft: matrix.m41 + 805
		};

		this.addNewRetroInfoDetail(item);
	}

	addNewItem(currentItem: any) {
		var item = {
			RetroInfoId: this.RetroInfoId,
			RetroInfoDetailAgilePointId: currentItem.AgilePointId,
			RetroInfoDetailText: currentItem.AgilePointText,
			RetroInfoDetailTop: "-500",
			RetroInfoDetailLeft: "300",
			RetroInfoDetailImageCategoryId: 1,
			RetroInfoDetailImageCategoryName: "test",
			RetroInfoDetailColor: "yellow"
		};

		this.addNewRetroInfoDetail(item);
	}

	dragEnded(event: any, currentItem: any) {
		var currentElement = event.source.element.nativeElement;
		var style = window.getComputedStyle(currentElement);
		var matrix = new WebKitCSSMatrix(style.webkitTransform);

		var item = {
			RetroInfoId: this.RetroInfoId,
			RetroInfoDetailId: currentItem.RetroInfoDetailId,
			RetroInfoDetailAgilePointId: currentItem.RetroInfoDetailAgilePointId,
			RetroInfoDetailText: currentItem.RetroInfoDetailText,
			RetroInfoDetailTop: matrix.m42,
			RetroInfoDetailLeft: matrix.m41,
			RetroInfoDetailImageCategoryId: currentItem.RetroInfoDetailImageCategoryId,
			RetroInfoDetailImageCategoryName: currentItem.RetroInfoDetailImageCategoryName,
			RetroInfoDetailColor: currentItem.RetroInfoDetailColor
		};

		this.updateRetroInfoDetailDetail(item);
	}

	findIndexToUpdate(currentItem) {
		return currentItem.RetroInfoDetailAgilePointId === this;
	}

	findIndexToUpdateAgilePointDetails(currentItem) {
		return currentItem.AgilePointId === this;
	}

	sendMessage(item: any): void {
		var siteUrl = 'https://signalr-hub-latest.azurewebsites.net/Message';
		this.httpClient.post(siteUrl, item).subscribe((response) => {
			console.log(response);
		}, error => {
			console.log(error);
		});
	}

	getFormDigest() {
		this.spinner.show();
		this.httpClientService.getFormDigest().subscribe((response: Response) => {
			this.spinner.hide();
			this.formDigestDetail = response;
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	addNewRetroInfoDetail(currentItem) {
		this.spinner.show();
		let listLibraryBookDetailsName = "RetroInfoDetail";
		var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
		var item = {
			"__metadata": { "type": itemlistLibraryBookDetailsNameType },
			RetroInfoId: this.RetroInfoId,
			RetroInfoDetailAgilePointId: currentItem.RetroInfoDetailAgilePointId,
			RetroInfoDetailText: currentItem.RetroInfoDetailText,
			RetroInfoDetailTop: String(currentItem.RetroInfoDetailTop),
			RetroInfoDetailLeft: String(currentItem.RetroInfoDetailLeft),
			RetroInfoDetailImageCategoryId: this.imageCategoryModel.ImageCategoryId,
			RetroInfoDetailImageCategoryName: this.imageCategoryModel.ImageCategoryText,
			RetroInfoDetailColor: this.imageCategoryModel.ImageCategoryColor,
			ImageCategoryFontColor: this.imageCategoryModel.ImageCategoryFontColor
		};

		var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items";

		this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
			this.spinner.hide();
			const newBookId = responce && responce.d && responce.d.ID;
			this.spinner.show();
			const getRetroInfoDetailById = this.httpRetroInfoDetailService.getRetroInfoDetailByIdLatest(this.RetroInfoId);
			forkJoin([getRetroInfoDetailById]).subscribe((response) => {
				this.spinner.hide();
				this.doneList = response[0];
				var todoList = this.todoList.filter(item => !this.doneList.some(other => item.AgilePointId == other.tile.RetroInfoDetailAgilePointId));
				this.todoList = todoList;
			}, error => {
				this.spinner.hide();
				console.log(error);
			});
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	updateRetroInfoDetailDetail(currentItem) {
		this.spinner.show();
		let listLibraryBookDetailsName = "RetroInfoDetail";
		var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
		var item = {
			"__metadata": { "type": itemlistLibraryBookDetailsNameType },
			RetroInfoId: this.RetroInfoId,
			RetroInfoDetailAgilePointId: currentItem.RetroInfoDetailAgilePointId,
			RetroInfoDetailText: currentItem.RetroInfoDetailText,
			RetroInfoDetailTop: String(currentItem.RetroInfoDetailTop),
			RetroInfoDetailLeft: String(currentItem.RetroInfoDetailLeft),
			RetroInfoDetailImageCategoryId: currentItem.RetroInfoDetailImageCategoryId,
			RetroInfoDetailImageCategoryName: currentItem.RetroInfoDetailImageCategoryName,
			RetroInfoDetailColor: currentItem.RetroInfoDetailColor,
			ImageCategoryFontColor: currentItem.ImageCategoryFontColor
		};

		var siteBookUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items(" + currentItem.RetroInfoDetailId + ")";

		let getBookDetail = this.httpClientService.httpMerge(siteBookUrl, item, this.formDigestDetail.FormDigestValue);

		forkJoin([getBookDetail]).subscribe((responce) => {
			this.spinner.hide();
			console.log(responce);
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	getItemTypeForListName(name) {
		return "SP.Data." + name.charAt(0).toUpperCase() + name.slice(1) + "ListItem";
	}

	public onEventLog(event: string, data: any): void {
		this.BackgroundColor = data;
	}

	public onEventFontLog(event: string, data: any): void {
		this.FontColor = data;
	}

	onChangeImageCategory(selectedCategory) {

		if (selectedCategory.target.selectedIndex > 0) {
			this.imageCategoryModel = this.imageCategory[selectedCategory.target.selectedIndex - 1];
			this.imageCategoryDefault = this.imageCategoryModel.ImageCategoryId.toString();
		}
		else {
			this.imageCategoryDefault = "0";
			this.imageCategoryModel = new ImageCategory("", "", "", "", "");
		}
	}

	addSave() {
		this.spinner.show();
		let listLibraryBookDetailsName = "RetroAgilePointDetail";
		var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
		var item = {
			"__metadata": { "type": itemlistLibraryBookDetailsNameType },
			AgilePointText: this.RetrospectivePointsText,
			AgilePointType: this.RetrospectivePointsCode
		};

		var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items";

		this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
			this.spinner.hide();
			const newBookId = responce && responce.d && responce.d.ID;
			console.log(newBookId);
			this.spinner.show();
			const getRetroAgilePointDetail = this.httpRetroInfoDetailService.getRetroAgilePointDetail();
			forkJoin([getRetroAgilePointDetail]).subscribe((response) => {

				this.spinner.hide();
				console.log(response);
				var todoList = response[0];
				this.todoList = todoList.filter(item => !this.doneList.some(other => item.AgilePointId == other.RetroInfoDetailAgilePointId));
				this.modalRef.hide();
				this.RetrospectivePointsCode = '';
				this.RetrospectivePointsText = '';
			}, error => {
				this.spinner.hide();
				console.log(error);
			});
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	addSaveCat() {
		if (this.imageCategoryDefault === '0') {
			this.spinner.show();
			let listLibraryBookDetailsName = "RetroImageCategoryDetail";
			var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
			var item = {
				"__metadata": { "type": itemlistLibraryBookDetailsNameType },
				ImageCategoryText: this.ImageCategoryText,
				ImageCategoryType: this.ImageCategoryCode,
				ImageCategoryColor: this.BackgroundColor,
				ImageCategoryFontColor: this.FontColor
			};

			var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items";

			this.httpClientService.httpPost(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
				this.spinner.hide();
				const newBookId = responce && responce.d && responce.d.ID;
				this.spinner.show();
				const getImageCategoryDetail = this.httpRetroInfoDetailService.getImageCategoryDetail(this.RetroInfoId);
				forkJoin([getImageCategoryDetail]).subscribe((response) => {
					this.spinner.hide();
					this.imageCategory = response[0];
					this.modalRefCat.hide();
					this.ImageCategoryCode = '';
					this.ImageCategoryText = '';
					this.BackgroundColor = '#2889e9';
					this.FontColor = '#59caa0';
					this.imageCategoryDefault = '0'
				}, error => {
					this.spinner.hide();
					console.log(error);
				});
			}, error => {
				this.spinner.hide();
				console.log(error);
			});
		} else {
			this.spinner.show();
			let listLibraryBookDetailsName = "RetroImageCategoryDetail";
			var itemlistLibraryBookDetailsNameType = this.getItemTypeForListName(listLibraryBookDetailsName);
			var item = {
				"__metadata": { "type": itemlistLibraryBookDetailsNameType },
				ImageCategoryText: this.ImageCategoryText,
				ImageCategoryType: this.ImageCategoryCode,
				ImageCategoryColor: this.BackgroundColor,
				ImageCategoryFontColor: this.FontColor
			};

			var siteUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items(" + this.imageCategoryDefault + ")";

			this.httpClientService.httpMerge(siteUrl, item, this.formDigestDetail.FormDigestValue).subscribe((responce: any) => {
				this.spinner.hide();
				const newBookId = responce && responce.d && responce.d.ID;
				this.spinner.show();
				const getImageCategoryDetail = this.httpRetroInfoDetailService.getImageCategoryDetail(this.RetroInfoId);
				forkJoin([getImageCategoryDetail]).subscribe((response) => {
					this.spinner.hide();
					this.imageCategory = response[0];
					this.modalRefCat.hide();
					this.ImageCategoryCode = '';
					this.ImageCategoryText = '';
					this.BackgroundColor = '#2889e9';
					this.FontColor = '#59caa0';
					this.imageCategoryDefault = '0'
				}, error => {
					this.spinner.hide();
					console.log(error);
				});
			}, error => {
				this.spinner.hide();
				console.log(error);
			});
		}
	}

	addCancel() {
		this.modalRef.hide();
		this.Description = '';
	}

	addCatCancel() {
		this.modalRefCat.hide();
		this.Description = '';
	}

	addNew(template: TemplateRef<any>) {
		this.modalRef = this.modalService.show(template, this.config);
	}

	addNewImageCategory(template: TemplateRef<any>) {
		this.modalRefCat = this.modalService.show(template, this.config);
	}

	addNewImageCategoryEdit(template: TemplateRef<any>) {
		const res = this.imageCategory.filter(x => x.ImageCategoryId == this.imageCategoryDefault);
		this.ImageCategoryCode = res[0].ImageCategoryType;
		this.ImageCategoryText = res[0].ImageCategoryText;
		this.BackgroundColor = res[0].ImageCategoryColor;
		this.FontColor = res[0].ImageCategoryFontColor;
		this.modalRefCat = this.modalService.show(template, this.config);
	}

	addNewView(template: TemplateRef<any>) {
		this.modalRefView = this.modalService.show(template, this.config);
	}

	addNewImageCategoryView(template: TemplateRef<any>) {
		this.modalRefCatView = this.modalService.show(template, this.config);
	}

	getBackgroundImageStyles() {
		const retroInfo = {} as any;
		let imageStyle = {
			'background-image': retroInfo ? 'url(' + retroInfo.retroinfo_imagepath + ')' : ''
		};
		return imageStyle;
	}

	DownloadRetroMeeting() {
		this.modalRefDownload.hide();
		var isFirefox = navigator.userAgent.search("Firefox");
		var isChrome = navigator.userAgent.search("Chrome");
		if (isFirefox > -1 || isChrome > -1) {
			let section = document.querySelector("#mainContent");
			html2canvas(section).then(canvas => {
				this.newMethod(canvas);
			});
		}
		else {
			this.newMethod(null);
		}
	}

	getBackgroundUrl() {
		if (this.retroInfo && this.retroInfo.retroinfo_imageBase64) {
			var imageBase64 = this.retroInfo.retroinfo_imageBase64.split('>');
			var imageBaseImageData = imageBase64[1];
			var imageBase = imageBaseImageData.replace('</div', '');
			// var res = this.retroInfo.retroinfo_imageBase64.replace(/^<div[^>]*>|<\/div>$/g, '');
			this.backgroundUrl = "data:image/png;base64," + imageBase;
		}
	}

	deleteItemEmit(retroId: any) {

		let listLibraryBookDetailsName = "RetroInfoDetail";
		var siteBookUrl = this.baseUrl + "_api/lists/getbytitle('" + listLibraryBookDetailsName + "')/items(" + retroId + ")";
		let deleteRetroItem = this.httpClientService.httpDelete(siteBookUrl, this.formDigestDetail.FormDigestValue);

		forkJoin([deleteRetroItem]).subscribe((responce) => {
			this.spinner.hide();
			console.log(responce);
			this.spinner.show();
			const getRetroInfoDetailById = this.httpRetroInfoDetailService.getRetroInfoDetailByIdLatest(this.RetroInfoId);
			forkJoin([getRetroInfoDetailById]).subscribe((response) => {
				this.spinner.hide();
				console.log(response);
				this.doneList = response[0];
				var todoList = this.todoList.filter(item => !this.doneList.some(other => item.AgilePointId == other.tile.RetroInfoDetailAgilePointId));
				this.todoList = todoList;
			}, error => {
				this.spinner.hide();
				console.log(error);
			});
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}

	getRetroTracker(retroInfo: any) {
		if (retroInfo != null && this.retroTrackerInfo != null) {
			return this.retroTrackerInfo.filter(c => c.RetroDetailId == retroInfo.tile.RetroInfoDetailId);;
		}

		return [];
	}

	getRetroNote(retroInfo: any) {
		if (retroInfo != null && this.retroFeedbackNote != null) {
			return this.retroFeedbackNote.filter(c => c.RetroDetailId == retroInfo.tile.RetroInfoDetailId);;
		}

		return [];
	}

	updateAgreeAndDisAgreeEmit(retroAgreeId: any) {
		this.evetWatcherUnTill();
	}

	selectEvent(item) {
		if (this.selectedItemVal != "") {
			this.isOpen = false;
		} else {
			this.isOpen = true;
		}
	}

	onChangeSearch(val: string) {
		if (this.selectedItemVal != "") {
			this.isOpen = false;
		} else {
			this.isOpen = true;
		}
	}

	onFocused(e) {
		if (this.selectedItemVal != "") {
			this.isOpen = false;
		} else {
			this.isOpen = true;
		}
	}

	closed(e) {
		if (this.selectedItemVal != "") {
			this.isOpen = false;
		} else {
			this.isOpen = true;
		}
	}

	opened(e) {
		if (this.selectedItemVal != "") {
			this.isOpen = false;
		} else {
			this.isOpen = true;
		}
	}

	private newMethod(canvas: any) {
		this.retroConpleteUpdate();
		
		const doneListDetails = this.doneList.map(item => {
			return new RetroInfoDetails(
				item.tile.RetroInfoId,
				item.tile.RetroInfoDetailId,
				item.tile.RetroInfoDetailAgilePointId,
				item.tile.RetroInfoDetailText,
				item.tile.RetroInfoDetailTop,
				item.tile.RetroInfoDetailLeft,
				item.tile.RetroInfoDetailImageCategoryId,
				item.tile.RetroInfoDetailImageCategoryName,
				item.tile.background,
				item.tile.FontColor
			);
		});

		const title = 'Retrospective Meeting Info';
		var result = doneListDetails.reduce(function (r, a) {
			r[a.RetroInfoDetailImageCategoryName] = r[a.RetroInfoDetailImageCategoryName] || [];
			r[a.RetroInfoDetailImageCategoryName].push(a);
			return r;
		}, Object.create(null));

		console.log(result);

		var headerData = Object.keys(result);

		// Create workbook and worksheet
		const workbook = new Workbook();
		const worksheet = workbook.addWorksheet('Retrospective Meeting Info');

		// Add Row and formatting
		const titleRow = worksheet.addRow([title]);
		titleRow.font = { name: 'Corbel', family: 4, size: 16, bold: true };
		titleRow.alignment = { horizontal: 'center', vertical: 'middle' };
		worksheet.addRow([]);
		worksheet.addRow([]);

		worksheet.addRow(['', 'Retro Name : ', this.retroInfo.retroinfo_name]);
		worksheet.addRow(['', 'Project Name : ', this.retroInfo.retroinfo_projectinfo_name]);
		worksheet.addRow(['', 'Sprint : ', this.retroInfo.retroinfo_sprint]);
		worksheet.addRow(['', 'Date :', this.retroInfo.retroinfo_date]);

		worksheet.mergeCells('A1:C2');


		// Blank Row
		worksheet.addRow([]);

		// Add Header Row
		const headerRow = worksheet.addRow(headerData);

		// Cell Style : Fill and Border
		headerRow.eachCell((cell, number) => {
			cell.fill = {
				type: 'pattern',
				pattern: 'solid',
				fgColor: { argb: 'FFCCFFE5' },
				bgColor: { argb: 'FFCCFFE5' }
			};
			cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
		});

		var newData = [];
		var maxLength = [];

		headerData.forEach((d) => {
			var res = doneListDetails.filter(x => x.RetroInfoDetailImageCategoryName === d);
			if (maxLength.length < res.length) {
				maxLength = res;
			}
		});

		headerData.forEach((d, index) => {
			var res = doneListDetails.filter(x => x.RetroInfoDetailImageCategoryName === d);

			if (newData.length === 0) {
				maxLength.forEach((item, indexItem) => {
					if (typeof res[indexItem] === 'undefined') {
						newData.push([""]);
					} else {
						var items = res[indexItem];
						newData.push([items.RetroInfoDetailText]);
					}
				});
			} else {
				maxLength.forEach((item, indexItem) => {
					if (typeof res[indexItem] === 'undefined') {
						var currentItem = newData[indexItem];
						currentItem.push("");
						newData[indexItem] = currentItem;
					}
					else {
						var currentItem = newData[indexItem];
						var items = res[indexItem];
						currentItem.push(items.RetroInfoDetailText);
						newData[indexItem] = currentItem;
					}
				});
			}
		});


		console.log(newData);

		// Add Data and Conditional Formatting
		newData.forEach(d => {
			const row = worksheet.addRow(d);
			// const qty = row.getCell(1);
			// let color = 'FF99FF99';
			// if (+qty.value < 500) {
			// 	color = 'FF9999';
			// }
			// qty.fill = {
			// 	type: 'pattern',
			// 	pattern: 'solid',
			// 	fgColor: { argb: color }
			// };
		}

		);

		worksheet.getColumn(1).width = 30;
		worksheet.getColumn(2).width = 30;
		worksheet.getColumn(3).width = 30;
		worksheet.addRow([]);

		// Footer Row
		const footerRow = worksheet.addRow(['This is system generated excel sheet.']);
		footerRow.getCell(1).fill = {
			type: 'pattern',
			pattern: 'solid',
			fgColor: { argb: 'FFCCFFE5' }
		};
		footerRow.getCell(1).border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };

		// Merge Cells
		worksheet.mergeCells(`A${footerRow.number}:C${footerRow.number}`);

		if (canvas != null) {
			var imageId2 = workbook.addImage({
				base64: canvas.toDataURL(),
				extension: 'png',
			});

			worksheet.addImage(imageId2, 'G2:N15');
		}

		// Generate Excel File with given name
		workbook.xlsx.writeBuffer().then((data: any) => {
			const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
			fs.saveAs(blob, 'Retro.xlsx');
		});

		this.mySubscription.unsubscribe();
	}

	colors: any[] = [
		{ name: 'Red', value: '#ff1744', foreground: 'white' },
		{ name: 'Pink', value: '#ff80ab', foreground: 'black' },
		{ name: 'Purple', value: '#d500f9', foreground: 'white' },
		{ name: 'Deep Purple', value: '#7c4dff', foreground: 'white' },
		{ name: 'Indigo', value: '#3d5afe', foreground: 'white' },
		{ name: 'Blue', value: '#2979ff', foreground: 'white' },
		{ name: 'Light Blue', value: '#00b0ff', foreground: 'black' },
		{ name: 'Cyan', value: '#00e5ff', foreground: 'black' },
		{ name: 'Teal', value: '#1de9b6', foreground: 'black' },
		{ name: 'Green', value: '#00e676', foreground: 'black' },
		{ name: 'Light Green', value: '#76ff03', foreground: 'black' },
		{ name: 'Lime', value: '#c6ff00', foreground: 'black' },
		{ name: 'Yellow', value: '#ffea00', foreground: 'black' },
		{ name: 'Amber', value: '#ffc400', foreground: 'black' },
		{ name: 'Orange', value: '#ff9100', foreground: 'black' },
		{ name: 'Deep Orange', value: '#ff3d00', foreground: 'white' },
		{ name: 'Brown', value: '#8d6e63', foreground: 'white' },
		{ name: 'Light Gray', value: '#bdbdbd', foreground: 'black' },
		{ name: 'Dark Gray', value: '#616161', foreground: 'white' },
		{ name: 'Blue Gray', value: '#78909c', foreground: 'white' }
	];

	placeholder: string = 'Enter Your Name';
	keyword = 'name';
	nameTemplate = [];

	getTeamNameDetails(teamId) {
		this.spinner.show();
		this.httpRetroInfoDetailService.getRetroTrackerNameById(teamId).subscribe(model => {
			this.nameTemplate = Array.from(new Set(model.map(x => x)));
			this.spinner.hide();
		});
	}

	modalRefDownload: BsModalRef;

	decline(): void {
		this.modalRefDownload.hide();
	}

	downloadConfirm(template: TemplateRef<any>) {
		this.modalRefDownload = this.modalService.show(template, { class: 'modal-sm' });
	}

	private retroConpleteUpdate() {
		debugger;
		this.spinner.show();
		let listRetroTrackerName = "RetroInfoModel";
		var itemlistRetroTrackerType = this.getItemTypeForListName(listRetroTrackerName);
		var item = {
			"__metadata": { "type": itemlistRetroTrackerType },
			RetroinfoStatus: "View"
		};

		var siteBookUrl = this.baseUrl + "_api/lists/getbytitle('" + listRetroTrackerName + "')/items(" + this.RetroInfoId + ")";
		let mergeReq = this.httpClientService.httpMerge(siteBookUrl, item, this.formDigestDetail.FormDigestValue);

		forkJoin([mergeReq]).subscribe((responce) => {
			this.spinner.hide();
			this.retroInfo.retroinfo_status = "View";
		}, error => {
			this.spinner.hide();
			console.log(error);
		});
	}
}