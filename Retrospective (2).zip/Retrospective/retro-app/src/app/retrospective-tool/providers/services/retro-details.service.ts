import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment.prod';
import { AgilePointDetails } from '../../models/agile-point-details';
import { ImageCategory } from '../../models/image-category';
import { RetroInfoDetails } from '../../models/retro-info-details';
import { ImageInfoDetails } from '../../models/image-info-details';
import { RetroInfoDetailResponse, RetroInfoModel } from '../../models/retro-info.model';
import { HttpClientService } from '../common/http-client.service';
import { RetroInfoDetailLatest } from '../../models/retro-info-details-latest';
import { RetroTracker } from '../../models/retro-tracker';
import { ProjectDetails } from '../../models/project-details';
import { RetroFeedbackNote } from '../../models/retro-feedback-note';
@Injectable()
export class RetroInfoService {

    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService) {
    }

    getRetroInfo(startItem: any, currentItem: any) {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroInfoModel')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d" + startItem + "&%24top=100";
        var apiURLLast = this.baseUrl + "_api/lists/getbytitle('RetroInfoModel')/items?$top=1&$select=Id&$orderby=Created%20desc";
        let getBooks = this.httpClientService.httpGet(apiURL);
        let getBooksCountLast = this.httpClientService.httpGet(apiURLLast);

        return forkJoin([getBooks, getBooksCountLast]).pipe(map((resspone: any) => {
            const courseDetails = resspone[0].value.map(item => {
                return new RetroInfoModel(
                    item.ID,
                    item.RetroinfoName,
                    item.RetroinfoProjectInfoId,
                    item.RetroinfoProjectInfoName,
                    item.RetroinfoSprint,
                    item.RetroinfoDate,
                    item.RetroinfoStatus,
                    item.RetroinfoImageBase64,
                    item.RetroinfoImageId
                );
            });

            return new RetroInfoDetailResponse(courseDetails, this.getRetroCountLatest(resspone[1]));
        }));
    }

    getRetroInfoModelId(RetroInfoModelId?: string): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroInfoModel')/items(" + RetroInfoModelId + ")";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const retroInfoModel = new RetroInfoModel(
                resspone.ID,
                resspone.RetroinfoName,
                resspone.RetroinfoProjectInfoId,
                resspone.RetroinfoProjectInfoName,
                resspone.RetroinfoSprint,
                resspone.RetroinfoDate,
                resspone.RetroinfoStatus,
                resspone.RetroinfoImageBase64,
                resspone.RetroinfoImageId
            );

            return retroInfoModel;
        }));
    }

    getRetroTrackerById(retroInfoId?: string): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroTracker')/items?$filter=RetroInfoId%20eq%20" + retroInfoId;
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const retroTracker = resspone.value.map(item => {
                return new RetroTracker(
                    item.ID,
                    item.RetroInfoId,
                    item.RetroDetailId,
                    item.TeamId,
                    item.Name,
                    item.AgreeOrDisAgree,
                );
            });

            return retroTracker;
        }));
    }

    getRetroFeedbackNoteById(retroInfoId?: any): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroFeedbackNote')/items?$filter=RetroDetailId%20eq%20" + retroInfoId;
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const retroFeedbackNote = resspone.value.map(item => {
                return new RetroFeedbackNote(
                    item.ID,
                    item.RetroInfoId,
                    item.RetroDetailId,
                    item.Name,
                    item.FeedbackNote
                );
            });

            return retroFeedbackNote;
        }));
    }

    getRetroTrackerNameById(teamId?: string): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroTracker')/items?$select=Name&$filter=TeamId%20eq%20" + teamId + "&$top=4500";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {
            const retroTrackerNameList = resspone.value.map(person => person.Name);
            return retroTrackerNameList;
        }));
    }

    getRetroInfoDetailById(retroInfoId?: string, pageId?: string): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroInfoDetail')/items?$filter=RetroInfoId%20eq%20 " + retroInfoId;
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {

            const retroInfoDetail = resspone.value.map(item => {
                return new RetroInfoDetails(
                    item.RetroInfoId,
                    item.ID,
                    item.RetroInfoDetailAgilePointId,
                    item.RetroInfoDetailText,
                    item.RetroInfoDetailTop,
                    item.RetroInfoDetailLeft,
                    item.RetroInfoDetailImageCategoryId,
                    item.RetroInfoDetailImageCategoryName,
                    item.RetroInfoDetailColor,
                    item.ImageCategoryFontColor
                );
            });

            return retroInfoDetail;
        }));
    }

    getRetroInfoDetailByIdLatest(retroInfoId?: string, pageId?: string): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroInfoDetail')/items?$filter=RetroInfoId%20eq%20 " + retroInfoId;
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {

            const retroInfoDetail = resspone.value.map(item => {
                return new RetroInfoDetailLatest(
                    false,
                    {
                        content: {
                            text: item.RetroInfoDetailText
                        },
                        background: item.RetroInfoDetailColor,
                        FontColor: item.ImageCategoryFontColor,
                        RetroInfoId: item.RetroInfoId,
                        RetroInfoDetailId: item.ID,
                        RetroInfoDetailAgilePointId: item.RetroInfoDetailAgilePointId,
                        RetroInfoDetailText: item.RetroInfoDetailText,
                        RetroInfoDetailTop: item.RetroInfoDetailTop,
                        RetroInfoDetailLeft: item.RetroInfoDetailLeft,
                        RetroInfoDetailImageCategoryId: item.RetroInfoDetailImageCategoryId,
                        RetroInfoDetailImageCategoryName: item.RetroInfoDetailImageCategoryName,
                        RetroInfoDetailColor: item.ImageCategoryFontColor
                    }
                )
            });

            return retroInfoDetail;
        }));
    }

    getRetroImageDetail(): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroImageDetail')/items";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {

            const agilePointDetail = resspone.value.map(item => {
                return new ImageInfoDetails(
                    item.ID,
                    item.RetroImageTitle,
                    "data:image/png;base64," + item.RetroImageBase64,
                    "data:image/png;base64," + item.RetroImageBase64
                );
            });

            return agilePointDetail;
        }));
    }

    getRetroTeamDetail(): Observable<any> {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroTeamList')/items";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {

            const projectDetails = resspone.value.map(item => {
                return new ProjectDetails(
                    item.ID,
                    item.TeamName
                );
            });

            return projectDetails;
        }));
    }

    getRetroAgilePointDetail(): Observable<any> {

        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroAgilePointDetail')/items";
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {

            const agilePointDetail = resspone.value.map(item => {
                return new AgilePointDetails(
                    item.ID,
                    item.AgilePointText,
                    item.AgilePointType
                );
            });

            return agilePointDetail;
        }));
    }

    getImageCategoryDetail(imageId: string): Observable<any> {

        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroImageCategoryDetail')/items?$filter=RetroImageId%20eq%20 " + imageId;
        return this.httpClientService.httpGet(apiURL).pipe(map((resspone: any) => {

            const imageCategoryDetail = resspone.value.map(item => {
                return new ImageCategory(
                    item.ID,
                    item.ImageCategoryText,
                    item.ImageCategoryType,
                    item.ImageCategoryColor,
                    item.ImageCategoryFontColor
                );
            });

            return imageCategoryDetail;
        }));
    }

    private getRetroCountLatest(resspone: any): any {
        if (resspone && resspone.value.length != 0) {
            return resspone.value[0].Id
        }
        return 0;
    }
}