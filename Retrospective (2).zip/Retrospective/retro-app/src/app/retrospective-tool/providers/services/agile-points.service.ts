import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment.prod';
import { RetroInfoDetailResponse, RetroInfoModel } from '../../models/retro-info.model';
import { HttpClientService } from '../common/http-client.service';

@Injectable()
export class HttpAgilePointService {

    baseUrl = environment.apiBaseUrl;

    constructor(private httpClientService: HttpClientService) {
    }

    getRetroInfo(startItem: any, currentItem: any) {
        var apiURL = this.baseUrl + "_api/lists/getbytitle('RetroInfoModel')/items?%24skiptoken=Paged%3dTRUE%26p_ID%3d" + startItem + "&%24top=100";
        var apiURLLast = this.baseUrl + "_api/lists/getbytitle('RetroInfoModel')/items?$top=1&$select=Id&$orderby=Created%20desc";
        let getBooks = this.httpClientService.httpGet(apiURL);
        let getBooksCountLast = this.httpClientService.httpGet(apiURLLast);

        return forkJoin([getBooks, getBooksCountLast]).pipe(map((resspone: any) => {
            const courseDetails = resspone[0].value.map(item => {
                return new RetroInfoModel(
                    item.RetroinfoId,
                    item.RetroinfoName,
                    item.RetroinfoProjectInfoId,
                    item.RetroinfoProjectInfoName,
                    item.RetroinfoSprint,
                    item.RetroinfoDate,
                    item.RetroinfoStatus,
                    item.RetroinfoImageBase64,
                    item.RetroinfoImageId
                );
            });

            return new RetroInfoDetailResponse(courseDetails, this.getRetroCountLatest(resspone[1]));
        }));
    }

    private getRetroCountLatest(resspone: any): any {
        if (resspone && resspone.value.length != 0) {
            return resspone.value[0].Id
        }
        return 0;
    }
}