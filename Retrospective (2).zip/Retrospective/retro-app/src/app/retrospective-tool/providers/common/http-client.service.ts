import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  formDigestDetail: any;
  baseUrl = environment.apiBaseUrl;

  constructor(private httpClient: HttpClient) {
  }

  getFormDigest(): Observable<any> {
    let options = {
      "accept": "application/json;odata=verbose",
      "contentType": "text/xml"
    };
    var siteUrl = this.baseUrl + "_api/contextinfo";
    return this.httpClient.post(siteUrl, options);
  }

  public httpGet(siteUrl: string): Observable<any> {
    return this.httpClient.get(siteUrl);
  }

  public httpPost(siteUrl: string, item: any, formDigestValue: any): Observable<any> {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8;odata=verbose',
      'Cache-Control': 'no-cache',
      'accept': 'application/json;odata=verbose',
      "X-HTTP-Method": "POST",
      "If-Match": "*",
      "X-RequestDigest": formDigestValue
    });

    let options = { headers: httpHeaders };
    return this.httpClient.post<any>(siteUrl, JSON.stringify(item), options);
  }

  public httpMerge(siteUrl: string, item: any, formDigestValue: any): Observable<any> {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8;odata=verbose',
      'Cache-Control': 'no-cache',
      'accept': 'application/json;odata=verbose',
      "X-HTTP-Method": "MERGE",
      "If-Match": "*",
      "X-RequestDigest": formDigestValue
    });
    let options = { headers: httpHeaders };
    return this.httpClient.post<any>(siteUrl, JSON.stringify(item), options);
  }

  public httpDelete(siteUrl: string, formDigestValue: any): Observable<any> {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8;odata=verbose',
      'Cache-Control': 'no-cache',
      'accept': 'application/json;odata=verbose',
      "X-HTTP-Method": "DELETE",
      "If-Match": "*",
      "X-RequestDigest": formDigestValue
    });
    let options = { headers: httpHeaders };
    return this.httpClient.delete<any>(siteUrl, options);
  }

  public getArrayBuffer(siteUrl: string): Observable<any> {
    return this.httpClient.get(siteUrl, {
      responseType: "arraybuffer",
      headers: {
        "Accept": "application/xml;odata=verbose",
        "X-Requested-With": "XMLHttpRequest",
      }
    });
  }
}
