export class ProjectDetails {
    /**
     * Constructor for ProjectDetails class
     * @param Id
     * @param Project
    */
    constructor(
        public Id: string,
        public Project: string) { }
} 