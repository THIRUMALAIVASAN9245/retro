export class RetroFeedbackNote {
    /**
     * Constructor for RetroFeedbackNote class
     * @param Id
     * @param RetroInfoId
     * @param RetroDetailId
     * @param Name
     * @param FeedbackNote
    */
    constructor(
        public Id: number,
        public RetroInfoId: number,
        public RetroDetailId: number,
        public Name: string,
        public FeedbackNote: string) { }
}