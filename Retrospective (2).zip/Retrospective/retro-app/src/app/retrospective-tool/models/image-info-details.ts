export class ImageInfoDetails {
    /**
     * Constructor for ImageInfoDetails class
     * @param ImageInfoId
     * @param title
     * @param image
     * @param thumbImage
    */
    constructor(
        public ImageInfoId: string,
        public title: string,
        public image: string,
        public thumbImage: string) { }
} 