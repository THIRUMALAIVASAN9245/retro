export class RetroTracker {
    /**
     * Constructor for RetroTracker class
     * @param Id
     * @param RetroInfoId
     * @param RetroDetailId
     * @param TeamId
     * @param Name
     * @param AgreeOrDisAgree
    */
    constructor(
        public Id: number,
        public RetroInfoId: number,
        public RetroDetailId: number,
        public TeamId: string,
        public Name: string,
        public AgreeOrDisAgree: string) { }
} 