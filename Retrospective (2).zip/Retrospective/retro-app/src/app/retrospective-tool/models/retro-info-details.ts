export class RetroInfoDetails {
    /**
     * Constructor for RetroInfoDetails class
     * @param RetroInfoId
     * @param RetroInfoDetailId
     * @param RetroInfoDetailAgilePointId
     * @param RetroInfoDetailText
     * @param RetroInfoDetailTop
     * @param RetroInfoDetailLeft
     * @param RetroInfoDetailImageCategoryId
     * @param RetroInfoDetailImageCategoryName
     * @param RetroInfoDetailColor
     * @param ImageCategoryFontColor
    */
    constructor(
        public RetroInfoId: number,
        public RetroInfoDetailId: number,
        public RetroInfoDetailAgilePointId: number,
        public RetroInfoDetailText: string,
        public RetroInfoDetailTop: string,
        public RetroInfoDetailLeft: string,
        public RetroInfoDetailImageCategoryId: number,
        public RetroInfoDetailImageCategoryName: string,
        public RetroInfoDetailColor: string,
        public ImageCategoryFontColor: string) { }
} 