export class ImageCategory {
    /**
     * Constructor for ImageCategory class
     * @param ImageCategoryId
     * @param ImageCategoryText
     * @param ImageCategoryType
     * @param ImageCategoryColor
     * @param ImageCategoryFontColor
    */
    constructor(
        public ImageCategoryId: string,
        public ImageCategoryText: string,
        public ImageCategoryType: string,
        public ImageCategoryColor: string,
        public ImageCategoryFontColor: string) { }
} 