export class RetroInfoDetailLatest {
    /**
     * Constructor for RetroInfoDetailLatest class
     * @param editable
     * @param tile
    */
    constructor(
        public editable: any,
        public tile: any) { }
} 