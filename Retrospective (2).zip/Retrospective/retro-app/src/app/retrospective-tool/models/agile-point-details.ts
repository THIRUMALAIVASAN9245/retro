export class AgilePointDetails {
    /**
     * Constructor for AgilePointDetails class
     * @param AgilePointId
     * @param AgilePointText
     * @param AgilePointType
    */
    constructor(
        public AgilePointId: number,
        public AgilePointText: string,
        public AgilePointType: string) { }
} 