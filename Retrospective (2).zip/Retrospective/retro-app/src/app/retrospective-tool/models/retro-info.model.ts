export interface IRetroInfoModel {
    retroinfo_id: string,
    retroinfo_name: string,
    retroinfo_projectinfo_id: string,
    retroinfo_projectinfo_name: string,
    retroinfo_sprint: string,
    retroinfo_date: string,
    retroinfo_status: string,
    retroinfo_imageBase64: any,
    retroinfo_image_id: string
}

export class RetroInfoModel implements IRetroInfoModel {
    /**
     * Constructor for RetroInfoDetails class
     * @param retroinfo_id
     * @param retroinfo_name
     * @param retroinfo_projectinfo_id
     * @param retroinfo_sprint
     * @param retroinfo_date
     * @param retroinfo_status
     * @param retroinfo_imageBase64
     *  @param retroinfo_image_id
    */
    constructor(
        public retroinfo_id: string,
        public retroinfo_name: string,
        public retroinfo_projectinfo_id: string,
        public retroinfo_projectinfo_name: string,
        public retroinfo_sprint: string,
        public retroinfo_date: string,
        public retroinfo_status: string,
        public retroinfo_imageBase64: any,
        public retroinfo_image_id: string) {
    }
}


export interface IRetroInfoDetailResponse {
    RetroInfoDetail: RetroInfoModel[],
    count: number
}

export class RetroInfoDetailResponse implements IRetroInfoDetailResponse {

    constructor(
        public RetroInfoDetail: RetroInfoModel[],
        public count: number) {
    }
}