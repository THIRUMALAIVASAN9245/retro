import { Component } from '@angular/core';

@Component({
  selector: 'app-temp-root',
  templateUrl: './app-temp.component.html'
})
export class AppTempComponent {
  title = 'animated-app';
}
